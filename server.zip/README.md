# MusicWeb
 This is a graduate internship project at the University of Transport

## Installation

```bash
npm i
cd .\client\
npm i
```
## Run 

Server run at port: 8989

Client run at port: 3000

Server
```bash
npm start
```
Client
```bash
cd .\client\
npm start
```
## Author

[Thach](https://www.facebook.com/Thach.Huynh.ZoneNop)
[Huy](https://www.facebook.com/huy.diep.3388630)

## License
[MIT](https://choosealicense.com/licenses/mit/)