exports.isEmpty = function (obj) {
  return Object.keys(obj).length === 0;
};
